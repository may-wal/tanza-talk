import { useEffect, useRef, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  Users,
  Landmark,
  Eye,
  MapPin,
  Mic,
  MicOff,
} from "lucide-react";
import { FaInstagram, FaYoutube, FaLinkedin } from "react-icons/fa";
import {
  motion,
  AnimatePresence,
  useMotionValue,
  useSpring,
  useScroll,
  useTransform,
  useInView,
} from "framer-motion";
import { hero, stats } from "../data/content";

// ---------------------------------------------------------------------------
// IMAGE REFERENCES
// Drop these files into src/images/ — the component picks them up automatically.
//
//  heroimg.png        → full auditorium / stage background  (Layer 1)
//  speaker-cutout.png → speaker PNG, ideally with transparent BG (Layer 6)
//
// Until speaker-cutout.png is available, the hero image is reused as a
// masked right-panel composite (still looks great with the gradient mask).
// ---------------------------------------------------------------------------
import heroimg from "../images/heroimg.png";

// When you have a dedicated speaker cut-out, replace the line below with:
// import speakerImg from "../images/speaker-cutout.png";
const speakerImg = heroimg; // ← swap to speaker-cutout.png when ready

// ---------------------------------------------------------------------------
// CONSTANTS — generated outside component to avoid per-render recreation
// ---------------------------------------------------------------------------

// 40 dust particles with deterministic pseudo-random positions/timings
const DUST = Array.from({ length: 40 }, (_, i) => ({
  id: i,
  x: ((i * 37 + 11) * 2.7) % 100,
  delay: ((i * 13) % 100) / 10,
  dur: 8 + ((i * 7) % 6),
  size: 1 + ((i * 3) % 2),
  opacity: 0.1 + ((i * 4) % 20) / 100,
}));

// 8 bokeh circles
const BOKEH = [
  { w: 320, h: 320, x: 8,  y: 15, dur: 18, delay: 0,  blur: 50 },
  { w: 210, h: 210, x: 73, y: 8,  dur: 23, delay: 3,  blur: 42 },
  { w: 160, h: 160, x: 48, y: 62, dur: 15, delay: 6,  blur: 36 },
  { w: 260, h: 260, x: 83, y: 48, dur: 20, delay: 2,  blur: 55 },
  { w: 190, h: 190, x: 28, y: 72, dur: 17, delay: 8,  blur: 40 },
  { w: 130, h: 130, x: 58, y: 82, dur: 26, delay: 4,  blur: 44 },
  { w: 220, h: 220, x: 13, y: 48, dur: 19, delay: 7,  blur: 48 },
  { w: 170, h: 170, x: 88, y: 78, dur: 16, delay: 1,  blur: 38 },
];

const iconMap = { users: Users, landmark: Landmark, eye: Eye, "map-pin": MapPin };

// ---------------------------------------------------------------------------
// StatItem — animated counter, copied from original and preserved
// ---------------------------------------------------------------------------
function splitValue(v) {
  const m = v.match(/^([\d.]+)(.*)$/);
  if (!m) return { number: 0, suffix: v };
  return { number: parseFloat(m[1]), suffix: m[2] };
}

function StatItem({ stat }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const [display, setDisplay] = useState(0);
  const Icon = iconMap[stat.icon];
  const { number, suffix } = splitValue(stat.value);

  useEffect(() => {
    if (!inView) return;
    const duration = 900;
    const start = performance.now();
    let frame;
    function tick(now) {
      const progress = Math.min((now - start) / duration, 1);
      setDisplay(Math.round(number * (1 - Math.pow(1 - progress, 3))));
      if (progress < 1) frame = requestAnimationFrame(tick);
    }
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [inView, number]);

  return (
    <div ref={ref} className="flex items-center gap-3">
      <motion.div
        whileHover={{ scale: 1.15, rotate: 6 }}
        transition={{ type: "spring", stiffness: 300 }}
        className="text-accent"
      >
        <Icon size={20} />
      </motion.div>
      <div>
        <div className="font-display text-xl sm:text-2xl text-cream tabular-nums leading-none">
          {display}
          {suffix}
        </div>
        <div className="text-xs text-cream/50 mt-0.5">{stat.label}</div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Layer 1 helper — cinematic background image with overlays
// ---------------------------------------------------------------------------
function CinematicBackground({ bgY }) {
  return (
    <motion.div
      className="absolute inset-0 overflow-hidden"
      style={{ y: bgY, willChange: "transform" }}
    >
      {/* Stage / auditorium image — slow continuous zoom */}
      <motion.img
        src={heroimg}
        alt=""
        aria-hidden="true"
        loading="eager"
        className="w-full h-full object-cover object-center"
        animate={{ scale: [1, 1.022, 1] }}
        transition={{
          duration: 26,
          repeat: Infinity,
          ease: "easeInOut",
          repeatType: "loop",
        }}
        style={{ willChange: "transform" }}
      />

      {/* Dark overlay — 70% */}
      <div
        className="absolute inset-0"
        style={{ background: "rgba(11,10,9,0.72)" }}
      />

      {/* Warm orange radial glow rising from the stage floor */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 75% 55% at 52% 88%, rgba(232,121,44,0.2) 0%, rgba(180,80,20,0.09) 45%, transparent 75%)",
        }}
      />

      {/* Vignette — darkens the edges like a cinema lens */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 130% 100% at 50% 50%, transparent 28%, rgba(0,0,0,0.78) 100%)",
        }}
      />

      {/* Colour grade — adds warm shadows at top and bottom */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to bottom, rgba(10,6,2,0.42) 0%, transparent 28%, transparent 68%, rgba(5,3,1,0.65) 100%)",
          mixBlendMode: "multiply",
        }}
      />
    </motion.div>
  );
}

// ---------------------------------------------------------------------------
// Layer 2 — audience depth blur strip along the bottom
// ---------------------------------------------------------------------------
function AudienceDepth() {
  return (
    <motion.div
      aria-hidden="true"
      className="absolute bottom-0 left-0 right-0 pointer-events-none"
      style={{ height: "38%", filter: "blur(1.5px)" }}
      animate={{ x: [0, 6, 0, -6, 0] }}
      transition={{ duration: 22, repeat: Infinity, ease: "easeInOut" }}
    >
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to top, rgba(5,3,1,0.65) 0%, rgba(10,5,2,0.25) 45%, transparent 100%)",
        }}
      />
    </motion.div>
  );
}

// ---------------------------------------------------------------------------
// Layer 3 — animated spotlight beams (CSS-driven rotation, FM-driven opacity)
// ---------------------------------------------------------------------------
function Spotlights({ scrollYProgress }) {
  // Brightness increases slightly as the user scrolls — the show is starting
  const opacity1 = useTransform(scrollYProgress, [0, 0.45], [0.22, 0.44]);
  const opacity2 = useTransform(scrollYProgress, [0, 0.45], [0.17, 0.38]);

  return (
    <div
      aria-hidden="true"
      className="absolute inset-0 pointer-events-none overflow-hidden"
    >
      {/* Beam 1 — from upper-left */}
      <motion.div style={{ opacity: opacity1 }} className="absolute inset-0">
        <div
          style={{
            position: "absolute",
            top: 0,
            left: "12%",
            width: "52%",
            height: "100%",
            background:
              "linear-gradient(158deg, rgba(255,215,130,0.38) 0%, rgba(255,180,80,0.16) 28%, transparent 62%)",
            clipPath: "polygon(8% 0%, 34% 0%, 96% 100%, -32% 100%)",
            transformOrigin: "22% 0%",
            animation: "spotlightSway 13s ease-in-out infinite alternate",
          }}
        />
      </motion.div>

      {/* Beam 2 — from upper-right */}
      <motion.div style={{ opacity: opacity2 }} className="absolute inset-0">
        <div
          style={{
            position: "absolute",
            top: 0,
            right: "8%",
            width: "48%",
            height: "100%",
            background:
              "linear-gradient(202deg, rgba(255,200,100,0.32) 0%, rgba(232,121,44,0.13) 28%, transparent 58%)",
            clipPath: "polygon(66% 0%, 92% 0%, 132% 100%, 4% 100%)",
            transformOrigin: "82% 0%",
            animation: "spotlightSway2 16s ease-in-out infinite alternate",
          }}
        />
      </motion.div>

      {/* Centre halo — subtle warm pool on the stage */}
      <motion.div
        style={{
          opacity: useTransform(scrollYProgress, [0, 0.45], [0.18, 0.35]),
        }}
        className="absolute inset-0 flex items-end justify-center"
      >
        <div
          style={{
            width: "60%",
            height: "50%",
            background:
              "radial-gradient(ellipse 80% 50% at 50% 100%, rgba(255,190,80,0.18) 0%, transparent 70%)",
          }}
        />
      </motion.div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Layer 4 — bokeh (large defocused circles, cinema lens emulation)
// ---------------------------------------------------------------------------
function BokehEffects() {
  return (
    <div
      aria-hidden="true"
      className="absolute inset-0 pointer-events-none overflow-hidden"
    >
      {BOKEH.map((c, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            width: c.w,
            height: c.h,
            left: `${c.x}%`,
            top: `${c.y}%`,
            borderRadius: "50%",
            background: `radial-gradient(circle, rgba(232,121,44,0.07) 0%, rgba(255,175,60,0.04) 50%, transparent 72%)`,
            filter: `blur(${c.blur}px)`,
            animation: `bokehDrift ${c.dur}s ${c.delay}s infinite ease-in-out alternate`,
            willChange: "transform",
          }}
        />
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Layer 5 — floating dust / golden motes drifting upward
// ---------------------------------------------------------------------------
function DustParticles() {
  return (
    <div
      aria-hidden="true"
      className="absolute inset-0 pointer-events-none overflow-hidden"
    >
      {DUST.map((p) => (
        <span
          key={p.id}
          style={{
            position: "absolute",
            left: `${p.x}%`,
            bottom: `-${p.size * 3}px`,
            width: `${p.size}px`,
            height: `${p.size}px`,
            borderRadius: "50%",
            background: "rgba(245,210,150,1)",
            opacity: p.opacity,
            animation: `dustDrift ${p.dur}s ${p.delay}s infinite linear`,
            willChange: "transform, opacity",
          }}
        />
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Layer 6 — speaker / hero image with cursor-driven parallax
// ---------------------------------------------------------------------------
function SpeakerLayer({ springX, springY, speakerScrollY }) {
  return (
    // Outer div handles scroll parallax
    <motion.div
      aria-hidden="true"
      className="absolute inset-0 pointer-events-none"
      style={{ y: speakerScrollY, willChange: "transform" }}
    >
      {/* Inner div handles cursor parallax */}
      <motion.div
        className="absolute inset-0"
        style={{ x: springX, y: springY, willChange: "transform" }}
      >
        {/* Ambient orange glow behind the speaker */}
        <div
          style={{
            position: "absolute",
            right: "3%",
            top: "5%",
            width: "58%",
            height: "95%",
            background:
              "radial-gradient(ellipse 55% 65% at 52% 58%, rgba(232,121,44,0.14) 0%, rgba(200,80,20,0.07) 48%, transparent 72%)",
            animation: "glowPulse 4.5s ease-in-out infinite alternate",
          }}
        />

        {/* Speaker image — masked at the left edge to blend into the scene */}
        <img
          src={speakerImg}
          alt="Speaker on stage"
          className="absolute right-0 bottom-0 h-full w-1/2 object-cover object-top"
          style={{
            maskImage:
              "linear-gradient(to left, rgba(0,0,0,0.92) 35%, rgba(0,0,0,0.4) 65%, rgba(0,0,0,0) 100%)",
            WebkitMaskImage:
              "linear-gradient(to left, rgba(0,0,0,0.92) 35%, rgba(0,0,0,0.4) 65%, rgba(0,0,0,0) 100%)",
          }}
        />
      </motion.div>
    </motion.div>
  );
}

// ---------------------------------------------------------------------------
// Scroll indicator — styled as a microphone silhouette + animated cue dot
// ---------------------------------------------------------------------------
function ScrollIndicator() {
  return (
    <motion.div
      className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-10 select-none"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 3.2, duration: 0.8 }}
      aria-label="Scroll to explore"
    >
      <span
        className="text-cream/35 text-[10px] tracking-[0.22em] uppercase font-medium"
        style={{ writingMode: "horizontal-tb" }}
      >
        Scroll
      </span>

      {/* Microphone SVG scroll indicator */}
      <svg
        width="22"
        height="42"
        viewBox="0 0 22 42"
        fill="none"
        aria-hidden="true"
        className="text-accent/60"
      >
        {/* Mic capsule */}
        <rect
          x="7"
          y="1"
          width="8"
          height="15"
          rx="4"
          stroke="currentColor"
          strokeWidth="1.4"
          fill="none"
        />
        {/* Cable down */}
        <line
          x1="11"
          y1="16"
          x2="11"
          y2="28"
          stroke="currentColor"
          strokeWidth="1.4"
          strokeLinecap="round"
        />
        {/* Stand arc */}
        <path
          d="M6 16 Q6 28 11 28 Q16 28 16 16"
          stroke="currentColor"
          strokeWidth="1.4"
          strokeLinecap="round"
          fill="none"
        />
        {/* Stand pole */}
        <line
          x1="11"
          y1="28"
          x2="11"
          y2="36"
          stroke="currentColor"
          strokeWidth="1.4"
          strokeLinecap="round"
        />
        {/* Base */}
        <line
          x1="6"
          y1="36"
          x2="16"
          y2="36"
          stroke="currentColor"
          strokeWidth="1.4"
          strokeLinecap="round"
        />
        {/* Animated cue dot (stage-cue metaphor) */}
        <motion.circle
          cx="11"
          cy="8"
          r="2.2"
          fill="currentColor"
          animate={{ cy: [7, 12, 7], opacity: [0.9, 0.15, 0.9] }}
          transition={{ duration: 2.1, repeat: Infinity, ease: "easeInOut" }}
        />
      </svg>
    </motion.div>
  );
}

// ---------------------------------------------------------------------------
// Ambient Audio Engine — never autoplays; activated by explicit user click
// ---------------------------------------------------------------------------
function AudioEngine() {
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef(null);

  const toggle = useCallback(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio("/audio/audience-ambience.mp3");
      audioRef.current.loop = true;
      audioRef.current.volume = 0.11;
    }
    if (playing) {
      audioRef.current.pause();
      setPlaying(false);
    } else {
      audioRef.current.play().catch(() => {
        // Browser blocked autoplay — silently fail
      });
      setPlaying(true);
    }
  }, [playing]);

  return (
    <motion.button
      onClick={toggle}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 3.5, duration: 0.8 }}
      className="absolute bottom-8 right-6 z-20 flex items-center gap-2 text-cream/35 hover:text-accent/80 transition-colors duration-300 group"
      aria-label={playing ? "Mute audience ambience" : "Play audience ambience"}
      id="hero-audio-toggle"
    >
      {playing ? <Mic size={13} /> : <MicOff size={13} />}
      <span className="text-[10px] tracking-[0.2em] uppercase">
        {playing ? "Live" : "Ambience"}
      </span>
      <span
        className={`w-1.5 h-1.5 rounded-full transition-colors ${
          playing ? "bg-accent animate-pulse" : "bg-cream/25"
        }`}
      />
    </motion.button>
  );
}

// ---------------------------------------------------------------------------
// First-visit intro overlay — near-dark → spotlight sweep → scene revealed
// Plays once; subsequent visits skip it via localStorage.
// ---------------------------------------------------------------------------
function IntroOverlay({ onComplete }) {
  return (
    <AnimatePresence>
      <motion.div
        key="intro-overlay"
        className="absolute inset-0 z-30 pointer-events-none"
        initial={{ opacity: 1 }}
        animate={{ opacity: 0 }}
        transition={{ duration: 1.4, delay: 1.6, ease: "easeOut" }}
        onAnimationComplete={onComplete}
        style={{ background: "rgba(0,0,0,0.94)" }}
      >
        {/* The signature spotlight sweep across the stage */}
        <motion.div
          className="absolute inset-0"
          initial={{ x: "-100%", opacity: 0 }}
          animate={{ x: "220%", opacity: [0, 0.8, 0] }}
          transition={{ duration: 1.4, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
          style={{
            background:
              "linear-gradient(90deg, transparent 0%, rgba(255,215,130,0.12) 38%, rgba(255,215,130,0.28) 50%, rgba(255,215,130,0.12) 62%, transparent 100%)",
          }}
        />
      </motion.div>
    </AnimatePresence>
  );
}

// ---------------------------------------------------------------------------
// Social rail — desktop only
// ---------------------------------------------------------------------------
function SocialRail() {
  return (
    <div className="hidden lg:flex flex-col items-center gap-5 absolute left-6 top-1/2 -translate-y-1/2 z-10">
      <span
        className="text-[10px] tracking-[0.3em] text-cream/35 uppercase"
        style={{ writingMode: "vertical-rl" }}
      >
        {hero.followLabel}
      </span>
      <div className="w-px h-8 bg-cream/15" />
      <a
        href="https://instagram.com"
        target="_blank"
        rel="noreferrer"
        aria-label="Instagram"
        className="text-cream/35 hover:text-accent transition-colors duration-300"
      >
        <FaInstagram size={15} />
      </a>
      <a
        href="https://youtube.com"
        target="_blank"
        rel="noreferrer"
        aria-label="YouTube"
        className="text-cream/35 hover:text-accent transition-colors duration-300"
      >
        <FaYoutube size={15} />
      </a>
      <a
        href="https://linkedin.com"
        target="_blank"
        rel="noreferrer"
        aria-label="LinkedIn"
        className="text-cream/35 hover:text-accent transition-colors duration-300"
      >
        <FaLinkedin size={15} />
      </a>
    </div>
  );
}

// ===========================================================================
// HERO — main export
// ===========================================================================
export default function Hero() {
  const sectionRef = useRef(null);

  // ── Intro sequence state ──────────────────────────────────────────────────
  // Check localStorage synchronously so returning visitors never see a flash
  const hasSeenIntro = typeof localStorage !== "undefined"
    ? !!localStorage.getItem("tt-intro-seen")
    : true;
  const [introComplete, setIntroComplete] = useState(hasSeenIntro);
  const [showIntro,     setShowIntro]     = useState(!hasSeenIntro);

  const handleIntroComplete = useCallback(() => {
    localStorage.setItem("tt-intro-seen", "1");
    setIntroComplete(true);
    setShowIntro(false);
  }, []);

  // ── Cursor parallax ───────────────────────────────────────────────────────
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);
  const springX = useSpring(rawX, { stiffness: 48, damping: 22 });
  const springY = useSpring(rawY, { stiffness: 48, damping: 22 });

  const handleMouseMove = useCallback(
    (e) => {
      const rect = sectionRef.current?.getBoundingClientRect();
      if (!rect) return;
      // ±8 px horizontal, ±6 px vertical
      rawX.set(((e.clientX - rect.left) / rect.width  - 0.5) * 16);
      rawY.set(((e.clientY - rect.top)  / rect.height - 0.5) * 12);
    },
    [rawX, rawY]
  );

  // Reset parallax when cursor leaves
  const handleMouseLeave = useCallback(() => {
    rawX.set(0);
    rawY.set(0);
  }, [rawX, rawY]);

  // ── Scroll-driven parallax + spotlight brightness ─────────────────────────
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"],
  });

  const bgY       = useTransform(scrollYProgress, [0, 1], ["0%",  "14%"]);
  const speakerScrollY = useTransform(scrollYProgress, [0, 1], ["0%", "-7%"]);
  const contentY  = useTransform(scrollYProgress, [0, 1], ["0%",  "-5%"]);

  // Stagger delays: 0 for returning visitors, generous for first visit
  // (first visit: intro overlay ends ~3s in; content then cascades in)
  const d = introComplete && !hasSeenIntro ? 0.05 : 0.15; // base delay
  const mk = (offset) => ({
    initial: { opacity: 0, y: 22 },
    animate: { opacity: introComplete ? 1 : 0, y: introComplete ? 0 : 22 },
    transition: { duration: 0.7, delay: d + offset, ease: [0.22, 1, 0.36, 1] },
  });

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative overflow-hidden min-h-screen flex flex-col"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{ background: "#0B0A09" }}
    >
      {/* ── LAYER 1 — Cinematic auditorium background ── */}
      <CinematicBackground bgY={bgY} />

      {/* ── LAYER 2 — Audience depth (blurred floor strip) ── */}
      <AudienceDepth />

      {/* ── LAYER 3 — Animated spotlights ── */}
      <Spotlights scrollYProgress={scrollYProgress} />

      {/* ── LAYER 4 — Bokeh / cinema-lens defocus circles ── */}
      <BokehEffects />

      {/* ── LAYER 5 — Floating dust motes ── */}
      <DustParticles />

      {/* ── LAYER 6 — Speaker image with cursor + scroll parallax ── */}
      <SpeakerLayer
        springX={springX}
        springY={springY}
        speakerScrollY={speakerScrollY}
      />

      {/* ── LAYER 7 — UI: nav rail, headline, CTA, stats ── */}

      {/* Desktop social rail */}
      <SocialRail />

      {/* Main content column */}
      <motion.div
        className="relative z-10 flex-1 flex items-center"
        style={{ y: contentY }}
      >
        <div className="max-w-8xl mx-auto container-px w-full py-24 lg:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            {/* ── LEFT COLUMN — text + CTA ── */}
            <div className="max-w-xl">

              {/* Eyebrow */}
              <motion.div
                {...mk(0)}
                className="flex items-center gap-3 mb-6"
              >
                <div className="w-6 h-px bg-accent shrink-0" />
                <p className="text-accent text-[11px] font-semibold tracking-[0.28em] uppercase">
                  Stories that move. Ideas that stay.
                </p>
              </motion.div>

              {/* Headline — revealed line by line */}
              <h1 className="font-display text-[2.6rem] sm:text-[4rem] md:text-[5.2rem] leading-[0.88] tracking-tight">
                {hero.heading.map((line, i) => {
                  const isItalicAccent =
                    line.fontVariant === "italic" || line.accent;
                  const isBold = line.fontVariant === "bold";

                  return (
                    <motion.span
                      key={i}
                      initial={{
                        opacity: 0,
                        y: 32,
                        clipPath: "inset(0 0 100% 0)",
                      }}
                      animate={
                        introComplete
                          ? { opacity: 1, y: 0, clipPath: "inset(0 0 0% 0)" }
                          : {}
                      }
                      transition={{
                        duration: 0.78,
                        delay: d + 0.14 + i * 0.13,
                        ease: [0.22, 1, 0.36, 1],
                      }}
                      className={`block ${
                        isItalicAccent
                          ? "hero-word--italic text-accent"
                          : isBold
                          ? "hero-word--bold text-cream"
                          : "text-cream"
                      }`}
                      style={
                        isItalicAccent
                          ? {
                              textShadow:
                                "0 0 38px rgba(232,121,44,0.48), 0 0 72px rgba(232,121,44,0.2)",
                            }
                          : {}
                      }
                    >
                      {line.text}
                    </motion.span>
                  );
                })}
              </h1>

              {/* Paragraph */}
              <motion.p
                {...mk(0.6)}
                className="mt-6 text-cream/58 text-base sm:text-lg max-w-md leading-relaxed"
              >
                {hero.paragraph}
              </motion.p>

              {/* CTA button — light sweep on hover */}
              <motion.div {...mk(0.82)} className="mt-9">
                <Link
                  to="/shows"
                  id="hero-cta"
                  className="hero-cta-btn group inline-flex items-center gap-3 bg-accent text-bg font-semibold text-sm px-8 py-4 rounded-full"
                >
                  <span className="relative z-10">{hero.primaryCta}</span>
                  <motion.span
                    className="relative z-10"
                    animate={{ x: [0, 4, 0] }}
                    transition={{
                      duration: 2.2,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                  >
                    <ArrowRight size={16} />
                  </motion.span>
                  {/* Sweeping gleam — pure CSS via the hero-cta-sweep class */}
                  <span className="hero-cta-sweep" aria-hidden="true" />
                </Link>
              </motion.div>

              {/* Stats strip */}
              <motion.div {...mk(1.04)} className="mt-10 w-full max-w-xl">
                <div className="bg-panel/35 backdrop-blur-md border border-white/[0.07] rounded-2xl px-4 sm:px-6 py-4">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
                    {stats.map((s, i) => (
                      <motion.div
                        key={s.label}
                        initial={{ opacity: 0, y: 14 }}
                        animate={
                          introComplete
                            ? { opacity: 1, y: 0 }
                            : { opacity: 0, y: 14 }
                        }
                        transition={{
                          duration: 0.55,
                          delay: d + 1.12 + i * 0.09,
                          ease: "easeOut",
                        }}
                      >
                        <StatItem stat={s} />
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            </div>
            {/* RIGHT COLUMN — speaker image (handled by Layer 6 absolute) */}
          </div>
        </div>
      </motion.div>

      {/* Microphone-style scroll indicator */}
      <ScrollIndicator />

      {/* Ambient audio toggle (never autoplays) */}
      <AudioEngine />

      {/* First-visit intro overlay */}
      {showIntro && <IntroOverlay onComplete={handleIntroComplete} />}
    </section>
  );
}
